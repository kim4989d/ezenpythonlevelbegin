
a=True
b=False

print(a)
print(b)

print(type(b))

print(1==1)
print(2<1)

print(bool('true'))
print(bool(''))

print(bool[1,2,3])
#print(bool[]) False error 오류

#1 true 0 false
print(bool(1))
print(bool(0))


