def Method1(input):
    return input
def Method2(input,input2):
    return input+input2


print(f"{Method1('입력')}")
print(f"{Method2(1,2)}")

