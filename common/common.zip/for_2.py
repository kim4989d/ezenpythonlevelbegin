<<<<<<< HEAD
for i in range(2,10) :
    for x in range(1,10):
        print("{0} x {1} = {2}".format(i,x,i*x),end="\t")
=======


result=0
for i in range(1,11):
  result=result+i

print(" 합은:",result)



for i in range(2,10):
    for x in range(1,10):
        print('{0} x {1} = {2}'.format(i,x,i*x),end="\t")
>>>>>>> origin/master

    print()



<<<<<<< HEAD
print('=' * 50)

=======
print('=' * 30)
>>>>>>> origin/master
for i in range(1,10):
    for x in range(2,10):
        print("{0} x {1} = {2}".format(x,i,x*i),end="\t")
    print()


<<<<<<< HEAD
=======


>>>>>>> origin/master
