if 'abc':
    print('if문 실행')
else:
    print('else문 실행')

# 출력값: if문 실행

if '':
    print('if문 실행')
else:
    print('else문 실행')

# 출력값: else문 실행

if [1, 2, 3]:
    print('if문 실행')
else:
    print('else문 실행')

# 출력값: if문 실행

if []:
    print('if문 실행')
else:
    print('else문 실행')

# 출력값: else문 실행
