if 'abc' == 'abc':
    print('if문 실행')
else:
    print('else문 실행')

# 출력값: if문 실행

if 'abc' != 'abc':
    print('if문 실행')
else:
    print(' else문 실행')

# 출력값: else문 실행

if 3 >= 2:
    print('if문 실행')
else:
    print('else문 실행')

# 출력값: if문 실행

if 3 < 2:
    print('if문 실행')
else:
    print('else문 실행')

# 출력값: else문 실행

#if 3 is 3.0:
 #   print('if문 실행')
#else:
 #   print('else문 실행')

# 출력값: else문 실행
