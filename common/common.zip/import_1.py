from common import class_1


class2=class_1.Class1()
print(class2.Ok('test22'))







