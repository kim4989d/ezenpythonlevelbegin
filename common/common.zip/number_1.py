
# 주석문
#주석문은 파이썬이 해석하지않는다(문법으로 보지않는다)

#변수 변할수있다 상수 변할수없다
#오른쪽에서 왼쪽으로 값을 저장한다



intvalue=10

print(intvalue)

#변수는 변할수있으므로 다시 저장할수 있다
#변수를 선언하고 print 로 출력할수있다
#변수가 print 밑으로 오면 에러 발생
#반드시 print 위에 있어야 한다
#파이썬은 각 줄에 마추어서 코딩을 해아한다

#실행 단축키 ctrl+ f5 , ctrl+shift+f10


intvalue=20
print(intvalue)

#본인 나이 출력

#decimal:10진수 0 ~ 10.11.12...
#사칙연산을 할수있다 (정수이므로 )
age=49
print(age)

a=10
b=2
print('=' * 30)
#더하기
result=a + b
print(result)

#빼기
print('=' * 30)
result=a - b
print(result)

#곱하기
print('=' * 30)
result=a * b
print(result)

# 나누기
print('=' * 30)
result=a % b
print(result)

# 몴
print('=' * 30)
result=a / b
print(result)








